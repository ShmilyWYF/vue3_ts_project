import userApi from "@/Api/userApi";

export const list = {userApi}
