export default {
    message: {
        lang: 'lang',
        cn: 'chinese',
        en: 'english',
        tag: 'RECOMMENDED',
        ALL: 'ALL',
        Docker: 'Docker'
    },
}
