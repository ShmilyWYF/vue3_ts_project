export default {
    message: {
        lang: '语言',
        cn: '中文',
        en: '英文',
        tag: '推荐文章',
        ALL: '全部',
        Docker: 'Docker'
    },
}
