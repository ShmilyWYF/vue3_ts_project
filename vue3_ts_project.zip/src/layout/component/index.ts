export {default as NavMenu} from './NavMenu/index.vue'
export {default as FooterTag} from './FooterTag/index.vue'
export {default as Main} from './Main/index.vue'
export {default as Drawer} from '@/components/Drawer/index.vue'
