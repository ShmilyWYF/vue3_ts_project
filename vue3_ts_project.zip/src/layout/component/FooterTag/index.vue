<template>
  <span>---------------------</span>
</template>
<script lang="ts">
export default {
  name: 'FooterTag',
  setup(){}
}
</script>
<style lang="scss" scoped>

</style>
