import template from '@/mock/menuApi/tempalte/menuTemplate'


const menuApi = [
  {
    url: '/menu/get',
    type: 'get',
    template,
    code: Number(200),
    status: true,
    condition: true
  },
]

export default menuApi
