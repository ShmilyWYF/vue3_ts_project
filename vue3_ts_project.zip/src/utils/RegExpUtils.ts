export function RegUrl(apiurl: string):RegExp {
    return RegExp(apiurl );
}
