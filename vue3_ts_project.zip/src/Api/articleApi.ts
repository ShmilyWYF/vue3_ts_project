export default {
    getArticleList: {
        method: 'get',
        url: 'get/articleFeatureList'
    },
    getArticleListByName:{
        method: 'get',
        url: 'get/articleListByName'
    },
    getFeatureArticle:{
        method: 'get',
        url: 'get/getFeatureArticle'
    }
}
