export default {
    getMenuRoles: {
        method: 'get',
        url: 'menu/get'
    },
}
