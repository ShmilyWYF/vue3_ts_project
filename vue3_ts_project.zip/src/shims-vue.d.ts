/* eslint-disable */
declare module '*.vue' {
    import type {DefineComponent} from 'vue'
    const component: DefineComponent<{}, {}, any>
  export default component
}

declare module 'node_modules/axios'

declare module 'mockjs'

declare module 'nprogress'

declare module 'inspector'
