<template>
  <div id="feature">
    <div v-if="loading">
      <div class="home-article mz-sk-pseudo mz-sk-pseudo-circle" style="height: 100%;">
        <div data-v-12a1800b="" class="Article mz-sk-pseudo mz-sk-pseudo-circle" style="border: none;">
          <div data-v-12a1800b="" class="el-card is-always-shadow mz-sk-pseudo mz-sk-pseudo-circle" style="height: 100%; border: none;">
            <!--v-if-->
            <div class="el-card__body mz-sk-transparent mz-sk-pseudo mz-sk-pseudo-circle" style="padding: 0px; height: 100%;">
              <div data-v-12a1800b="" class="feature-article-horizontal mz-sk-pseudo mz-sk-pseudo-circle">
                <div data-v-12a1800b="" class="feature-thumbnail mz-sk-pseudo mz-sk-pseudo-circle"><img data-v-12a1800b="" class="ob-hz-thumbnail mz-sk-pseudo mz-sk-pseudo-circle mz-sk-image mz-sk-rect" src="https://static.linhaojun.top/aurora/articles/3ec095cd9b7bd3f766166a4db14160c6.jpg" alt="背景图片"><span data-v-12a1800b="" class="thumbnail-screen mz-sk-pseudo mz-sk-pseudo-circle mz-sk-image mz-sk-rect" style="background: linear-gradient(130deg, rgb(36, 198, 220), rgb(84, 51, 255) 41.07%, rgb(255, 0, 153) 76.05%);"></span></div>
                <div data-v-12a1800b="" class="feature-content mz-sk-pseudo mz-sk-pseudo-circle"><span data-v-12a1800b="" class="mz-sk-pseudo mz-sk-pseudo-circle"><b data-v-12a1800b="" class="mz-sk-transparent mz-sk-text mz-sk-pseudo mz-sk-pseudo-circle">Docker</b>
                                                <ul data-v-12a1800b="" class="mz-sk-pseudo mz-sk-pseudo-circle">
                                                    <li data-v-12a1800b="" class="mz-sk-pseudo mz-sk-pseudo-circle"><em data-v-12a1800b="" class="mz-sk-transparent mz-sk-text mz-sk-pseudo mz-sk-pseudo-circle"># Docker</em></li>
                                                </ul>
                                            </span>
                  <h1 data-v-12a1800b="" class="article-title mz-sk-pseudo mz-sk-pseudo-circle"><a data-v-12a1800b="" class="mz-sk-pseudo mz-sk-pseudo-circle"><a data-v-12a1800b="" href="#/docker/1-1" class="mz-sk-pseudo mz-sk-pseudo-circle"><span data-v-12a1800b="" class="mz-sk-transparent mz-sk-text mz-sk-pseudo mz-sk-pseudo-circle">docker入门</span></a></a></h1>
                  <p data-v-12a1800b="" class="mz-sk-pseudo mz-sk-pseudo-circle"><span class="mz-sk-transparent mz-sk-text mz-sk-pseudo mz-sk-pseudo-circle">1.docker概述1.1 基本介绍Docker是一个开源的应用容器引擎，基于 Go 语言并遵从 Apache2.0 协议开源。Docker 可以让开发者打包他们的应用以及依赖包到一个轻量级、可移植的容器中，然后发布到任何流行的 Linux机器上也可以实现虚拟化容器是完全使用沙箱机制，相互之间不会有任何接口,更重要的是容器性能开销极低。Docker 从 17.03 版本之后分为 CE（Community Edition: 社区版） 和 EE（Enterprise Edition: 企业版），我们用社区版就可以了。官网1.2 应用场景Web 应用的自动化打包和发布。</span></p>
                  <div data-v-12a1800b="" class="article-footer mz-sk-pseudo mz-sk-pseudo-circle">
                    <div data-v-12a1800b="" class="flex flex-row items-center mz-sk-pseudo mz-sk-pseudo-circle"><img data-v-12a1800b="" class="hover:opacity-50 cursor-pointer mz-sk-image mz-sk-rect mz-sk-pseudo mz-sk-pseudo-circle" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" style="border: none;" width="0" height="0"><span data-v-12a1800b="" class="text-ob-dim mz-sk-pseudo mz-sk-pseudo-circle"><strong data-v-12a1800b="" class="text-ob-normal pr-1.5 hover:text-ob hover:opacity-50 cursor-pointer mz-sk-transparent mz-sk-text mz-sk-pseudo mz-sk-pseudo-circle">wyf</strong><strong data-v-12a1800b="" class="text-ob-normal pr-1.5 hover:text-ob hover:opacity-50 cursor-pointer mz-sk-transparent mz-sk-text mz-sk-pseudo mz-sk-pseudo-circle" style="margin: 0px 0px 0px 5px;"> 发布于 一月 20 , 1970</strong></span></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="mz-sk-transparent mz-sk-pseudo mz-sk-pseudo-circle">
          <div data-v-4677ae7a="" data-v-d9685000="" class="FeatureList mz-sk-transparent mz-sk-pseudo mz-sk-pseudo-circle">
            <div data-v-4677ae7a="" class="el-card is-always-shadow feature-article-list-box mz-sk-pseudo mz-sk-pseudo-circle mz-sk-image mz-sk-rect">
              <!--v-if-->
              <div class="el-card__body mz-sk-transparent mz-sk-pseudo mz-sk-pseudo-circle" style="height: 100%; padding: 0px;">
                <div data-v-4677ae7a="" class="shadow-md mz-sk-pseudo mz-sk-pseudo-circle" style="border: none;">
                  <h2 data-v-4677ae7a="" class="mz-sk-pseudo mz-sk-pseudo-circle">
                    <p data-v-4677ae7a="" class="mz-sk-pseudo mz-sk-pseudo-circle"><span class="mz-sk-transparent mz-sk-text mz-sk-pseudo mz-sk-pseudo-circle">EDITOR'S SELECTION</span></p><span data-v-4677ae7a="" class="mz-sk-pseudo mz-sk-pseudo-circle">
                                                    <p data-v-4677ae7a="" class="mz-sk-pseudo mz-sk-pseudo-circle"><span class="mz-sk-transparent mz-sk-text mz-sk-pseudo mz-sk-pseudo-circle">推荐文章</span></p>
                                                </span>
                  </h2>
                </div>
              </div>
            </div>
            <div data-v-12a1800b="" data-v-4677ae7a="" class="Article mz-sk-pseudo mz-sk-pseudo-circle" style="border: none;">
              <div data-v-12a1800b="" class="el-card is-always-shadow mz-sk-pseudo mz-sk-pseudo-circle" style="height: 100%; border: none;">
                <!--v-if-->
                <div class="el-card__body mz-sk-transparent mz-sk-pseudo mz-sk-pseudo-circle" style="padding: 0px; height: 100%;">
                  <div data-v-12a1800b="" class="feature-article-Vertical mz-sk-pseudo mz-sk-pseudo-circle">
                    <div data-v-12a1800b="" class="feature-thumbnail mz-sk-pseudo mz-sk-pseudo-circle"><img data-v-12a1800b="" class="ob-hz-thumbnail mz-sk-pseudo mz-sk-pseudo-circle mz-sk-image mz-sk-rect" src="https://static.linhaojun.top/aurora/articles/fcb421837abd7e593fbfd359112bb26c.jpg" alt="背景图片"><span data-v-12a1800b="" class="thumbnail-screen mz-sk-pseudo mz-sk-pseudo-circle mz-sk-image mz-sk-rect" style="background: linear-gradient(130deg, rgb(36, 198, 220), rgb(84, 51, 255) 41.07%, rgb(255, 0, 153) 76.05%);"></span></div>
                    <div data-v-12a1800b="" class="feature-content mz-sk-pseudo mz-sk-pseudo-circle"><span data-v-12a1800b="" class="mz-sk-pseudo mz-sk-pseudo-circle"><b data-v-12a1800b="" class="mz-sk-transparent mz-sk-text mz-sk-pseudo mz-sk-pseudo-circle">Docker</b>
                                                        <ul data-v-12a1800b="" class="mz-sk-pseudo mz-sk-pseudo-circle">
                                                            <li data-v-12a1800b="" class="mz-sk-pseudo mz-sk-pseudo-circle"><em data-v-12a1800b="" class="mz-sk-transparent mz-sk-text mz-sk-pseudo mz-sk-pseudo-circle"># Docker</em></li>
                                                        </ul>
                                                    </span>
                      <h1 data-v-12a1800b="" class="article-title mz-sk-pseudo mz-sk-pseudo-circle"><a data-v-12a1800b="" class="mz-sk-pseudo mz-sk-pseudo-circle"><a data-v-12a1800b="" href="#/docker/1-1" class="mz-sk-pseudo mz-sk-pseudo-circle"><span data-v-12a1800b="" class="mz-sk-transparent mz-sk-text mz-sk-pseudo mz-sk-pseudo-circle">docker入门</span></a></a></h1>
                      <p data-v-12a1800b="" class="mz-sk-pseudo mz-sk-pseudo-circle"><span class="mz-sk-transparent mz-sk-text mz-sk-pseudo mz-sk-pseudo-circle">1.docker概述1.1 基本介绍Docker是一个开源的应用容器引擎，基于 Go 语言并遵从 Apache2.0 协议开源。Docker 可以让开发者打包他们的应用以及依赖包到一个轻量级、可移植的容器中，然后发布到任何流行的 Linux机器上也可以实现虚拟化容器是完全使用沙箱机制，相互之间不会有任何接口,更重要的是容器性能开销极低。Docker 从 17.03 版本之后分为 CE（Community Edition: 社区版） 和 EE（Enterprise Edition: 企业版），我们用社区版就可以了。官网1.2 应用场景Web 应用的自动化打包和发布。</span></p>
                      <div data-v-12a1800b="" class="article-footer mz-sk-pseudo mz-sk-pseudo-circle">
                        <div data-v-12a1800b="" class="flex flex-row items-center mz-sk-pseudo mz-sk-pseudo-circle"><img data-v-12a1800b="" class="hover:opacity-50 cursor-pointer mz-sk-image mz-sk-rect mz-sk-pseudo mz-sk-pseudo-circle" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" style="border: none;" width="0" height="0"><span data-v-12a1800b="" class="text-ob-dim mz-sk-pseudo mz-sk-pseudo-circle"><strong data-v-12a1800b="" class="text-ob-normal pr-1.5 hover:text-ob hover:opacity-50 cursor-pointer mz-sk-transparent mz-sk-text mz-sk-pseudo mz-sk-pseudo-circle">wyf</strong><strong data-v-12a1800b="" class="text-ob-normal pr-1.5 hover:text-ob hover:opacity-50 cursor-pointer mz-sk-transparent mz-sk-text mz-sk-pseudo mz-sk-pseudo-circle" style="margin: 0px 0px 0px 5px;"> 发布于 一月 20 , 1970</strong></span></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div data-v-12a1800b="" data-v-4677ae7a="" class="Article mz-sk-pseudo mz-sk-pseudo-circle" style="border: none;">
              <div data-v-12a1800b="" class="el-card is-always-shadow mz-sk-pseudo mz-sk-pseudo-circle" style="height: 100%; border: none;">
                <!--v-if-->
                <div class="el-card__body mz-sk-transparent mz-sk-pseudo mz-sk-pseudo-circle" style="padding: 0px; height: 100%;">
                  <div data-v-12a1800b="" class="feature-article-Vertical mz-sk-pseudo mz-sk-pseudo-circle">
                    <div data-v-12a1800b="" class="feature-thumbnail mz-sk-pseudo mz-sk-pseudo-circle"><img data-v-12a1800b="" class="ob-hz-thumbnail mz-sk-pseudo mz-sk-pseudo-circle mz-sk-image mz-sk-rect" src="https://static.linhaojun.top/aurora/articles/fcb421837abd7e593fbfd359112bb26c.jpg" alt="背景图片"><span data-v-12a1800b="" class="thumbnail-screen mz-sk-pseudo mz-sk-pseudo-circle mz-sk-image mz-sk-rect" style="background: linear-gradient(130deg, rgb(36, 198, 220), rgb(84, 51, 255) 41.07%, rgb(255, 0, 153) 76.05%);"></span></div>
                    <div data-v-12a1800b="" class="feature-content mz-sk-pseudo mz-sk-pseudo-circle"><span data-v-12a1800b="" class="mz-sk-pseudo mz-sk-pseudo-circle"><b data-v-12a1800b="" class="mz-sk-transparent mz-sk-text mz-sk-pseudo mz-sk-pseudo-circle">Docker</b>
                                                        <ul data-v-12a1800b="" class="mz-sk-pseudo mz-sk-pseudo-circle">
                                                            <li data-v-12a1800b="" class="mz-sk-pseudo mz-sk-pseudo-circle"><em data-v-12a1800b="" class="mz-sk-transparent mz-sk-text mz-sk-pseudo mz-sk-pseudo-circle"># Docker</em></li>
                                                        </ul>
                                                    </span>
                      <h1 data-v-12a1800b="" class="article-title mz-sk-pseudo mz-sk-pseudo-circle"><a data-v-12a1800b="" class="mz-sk-pseudo mz-sk-pseudo-circle"><a data-v-12a1800b="" href="#/docker/1-1" class="mz-sk-pseudo mz-sk-pseudo-circle"><span data-v-12a1800b="" class="mz-sk-transparent mz-sk-text mz-sk-pseudo mz-sk-pseudo-circle">docker入门</span></a></a></h1>
                      <p data-v-12a1800b="" class="mz-sk-pseudo mz-sk-pseudo-circle"><span class="mz-sk-transparent mz-sk-text mz-sk-pseudo mz-sk-pseudo-circle">1.docker概述1.1 基本介绍Docker是一个开源的应用容器引擎，基于 Go 语言并遵从 Apache2.0 协议开源。Docker 可以让开发者打包他们的应用以及依赖包到一个轻量级、可移植的容器中，然后发布到任何流行的 Linux机器上也可以实现虚拟化容器是完全使用沙箱机制，相互之间不会有任何接口,更重要的是容器性能开销极低。Docker 从 17.03 版本之后分为 CE（Community Edition: 社区版） 和 EE（Enterprise Edition: 企业版），我们用社区版就可以了。官网1.2 应用场景Web 应用的自动化打包和发布。</span></p>
                      <div data-v-12a1800b="" class="article-footer mz-sk-pseudo mz-sk-pseudo-circle">
                        <div data-v-12a1800b="" class="flex flex-row items-center mz-sk-pseudo mz-sk-pseudo-circle"><img data-v-12a1800b="" class="hover:opacity-50 cursor-pointer mz-sk-image mz-sk-rect mz-sk-pseudo mz-sk-pseudo-circle" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" style="border: none;" width="0" height="0"><span data-v-12a1800b="" class="text-ob-dim mz-sk-pseudo mz-sk-pseudo-circle"><strong data-v-12a1800b="" class="text-ob-normal pr-1.5 hover:text-ob hover:opacity-50 cursor-pointer mz-sk-transparent mz-sk-text mz-sk-pseudo mz-sk-pseudo-circle">wyf</strong><strong data-v-12a1800b="" class="text-ob-normal pr-1.5 hover:text-ob hover:opacity-50 cursor-pointer mz-sk-transparent mz-sk-text mz-sk-pseudo mz-sk-pseudo-circle" style="margin: 0px 0px 0px 5px;"> 发布于 一月 20 , 1970</strong></span></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!--遮罩-->
          <div data-v-d9685000="" class="app-banner app-banner-screen app-banner-image mz-sk-pseudo mz-sk-pseudo-circle mz-sk-image mz-sk-rect"></div>
        </div>
      </div>
     </div>
    <div v-else class="home-article">
      <Article :data='top||{}' type="0"/>
      <div class="slot-box">
        <slot name="FeatureList" :list="list||[{},{}]"/>
        <slot name="appBanner"/>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import {computed, toRaw} from "vue";
const name = 'Feature'
import {Article} from "@/components";
import {ArticleInterface} from "@/interface";

interface FeatureDatainterface {
  LIST:ArticleInterface[]
  TOP:ArticleInterface
}

const props = defineProps<{
  FeatureData : FeatureDatainterface|undefined,
  loading: boolean,
}>()

const top = computed(()=>toRaw(props.FeatureData?.TOP))
const list = computed(()=>toRaw(props.FeatureData?.LIST))

</script>

<style lang="scss">
@media (min-width: 1024px) {
  #feature{
   height: 120% !important;
    .home-article {
      grid-template-rows: repeat(2,minmax(0,1fr)) !important;
      grid-gap: 3% 0 !important;
    }
  }
}
#feature {
  // 盒子初始化样式
  width: 85%;
  height: 180%;
  display: flex;
  flex-direction: column;
  color: var(--background-secondary);
  margin: 0 auto;
  position: relative;
  z-index: 10;
  //background: var(--feature-Background);
  opacity: 1;
  transition: opacity .3s ease-in-out;
  .home-article{
    height: 98%;
    display: grid;
    grid-template-rows: repeat(1, 28% 71%);
    grid-gap: 1% 0;
    width: 100%;
    margin: 2% auto 0 auto;
    .slot-box{
      height: 100%
    }
  }

  .el-card.is-always-shadow {
    box-shadow: var(--feature-box-card-shadow-light);
  }

  @media(min-width: 1024px) {
    .app-banner-screen {
      transition: opacity .3s ease-in-out !important;
      z-index: 2 !important;
      opacity: .91 !important;
    }
  }
  .app-banner {
    display: block;
    height: 55%;
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    background: var(--feature-app-banner-Background);
    -webkit-clip-path: polygon(100% 0, 0 0, 0 77.5%, 1% 77.4%, 2% 77.1%, 3% 76.6%, 4% 75.9%, 5% 75.05%, 6% 74.05%, 7% 72.95%, 8% 71.75%, 9% 70.55%, 10% 69.3%, 11% 68.05%, 12% 66.9%, 13% 65.8%, 14% 64.8%, 15% 64%, 16% 63.35%, 17% 62.85%, 18% 62.6%, 19% 62.5%, 20% 62.65%, 21% 63%, 22% 63.5%, 23% 64.2%, 24% 65.1%, 25% 66.1%, 26% 67.2%, 27% 68.4%, 28% 69.65%, 29% 70.9%, 30% 72.15%, 31% 73.3%, 32% 74.35%, 33% 75.3%, 34% 76.1%, 35% 76.75%, 36% 77.2%, 37% 77.45%, 38% 77.5%, 39% 77.3%, 40% 76.95%, 41% 76.4%, 42% 75.65%, 43% 74.75%, 44% 73.75%, 45% 72.6%, 46% 71.4%, 47% 70.15%, 48% 68.9%, 49% 67.7%, 50% 66.55%, 51% 65.5%, 52% 64.55%, 53% 63.75%, 54% 63.15%, 55% 62.75%, 56% 62.55%, 57% 62.5%, 58% 62.7%, 59% 63.1%, 60% 63.7%, 61% 64.45%, 62% 65.4%, 63% 66.45%, 64% 67.6%, 65% 68.8%, 66% 70.05%, 67% 71.3%, 68% 72.5%, 69% 73.6%, 70% 74.65%, 71% 75.55%, 72% 76.35%, 73% 76.9%, 74% 77.3%, 75% 77.5%, 76% 77.45%, 77% 77.25%, 78% 76.8%, 79% 76.2%, 80% 75.4%, 81% 74.45%, 82% 73.4%, 83% 72.25%, 84% 71.05%, 85% 69.8%, 86% 68.55%, 87% 67.35%, 88% 66.2%, 89% 65.2%, 90% 64.3%, 91% 63.55%, 92% 63%, 93% 62.65%, 94% 62.5%, 95% 62.55%, 96% 62.8%, 97% 63.3%, 98% 63.9%, 99% 64.75%, 100% 65.7%);
    clip-path: polygon(100% 0, 0 0, 0 77.5%, 1% 77.4%, 2% 77.1%, 3% 76.6%, 4% 75.9%, 5% 75.05%, 6% 74.05%, 7% 72.95%, 8% 71.75%, 9% 70.55%, 10% 69.3%, 11% 68.05%, 12% 66.9%, 13% 65.8%, 14% 64.8%, 15% 64%, 16% 63.35%, 17% 62.85%, 18% 62.6%, 19% 62.5%, 20% 62.65%, 21% 63%, 22% 63.5%, 23% 64.2%, 24% 65.1%, 25% 66.1%, 26% 67.2%, 27% 68.4%, 28% 69.65%, 29% 70.9%, 30% 72.15%, 31% 73.3%, 32% 74.35%, 33% 75.3%, 34% 76.1%, 35% 76.75%, 36% 77.2%, 37% 77.45%, 38% 77.5%, 39% 77.3%, 40% 76.95%, 41% 76.4%, 42% 75.65%, 43% 74.75%, 44% 73.75%, 45% 72.6%, 46% 71.4%, 47% 70.15%, 48% 68.9%, 49% 67.7%, 50% 66.55%, 51% 65.5%, 52% 64.55%, 53% 63.75%, 54% 63.15%, 55% 62.75%, 56% 62.55%, 57% 62.5%, 58% 62.7%, 59% 63.1%, 60% 63.7%, 61% 64.45%, 62% 65.4%, 63% 66.45%, 64% 67.6%, 65% 68.8%, 66% 70.05%, 67% 71.3%, 68% 72.5%, 69% 73.6%, 70% 74.65%, 71% 75.55%, 72% 76.35%, 73% 76.9%, 74% 77.3%, 75% 77.5%, 76% 77.45%, 77% 77.25%, 78% 76.8%, 79% 76.2%, 80% 75.4%, 81% 74.45%, 82% 73.4%, 83% 72.25%, 84% 71.05%, 85% 69.8%, 86% 68.55%, 87% 67.35%, 88% 66.2%, 89% 65.2%, 90% 64.3%, 91% 63.55%, 92% 63%, 93% 62.65%, 94% 62.5%, 95% 62.55%, 96% 62.8%, 97% 63.3%, 98% 63.9%, 99% 64.75%, 100% 65.7%);
  }
  .app-banner-image {
    z-index: 1;
    background-size: cover;
    opacity: 1;
    transition: opacity .3s ease-in-out;
  }

}
</style>
